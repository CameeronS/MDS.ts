import { createContext, useEffect, useRef } from "react"
export const appContext = createContext({} as any)
import { MDS } from "../../../src/index"

const AppProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const loaded = useRef<boolean>(false)

  useEffect(() => {
    MDS.init((msg) => {
      if (msg.event === "inited") {
        MDS.log("MDS initialized testinga")
      }

      MDS.log("MDS initialized testingb" + JSON.stringify(msg))

      MDS.cmd(
        "checkaddress",
        {
          address:
            "MxG0860NKQQK8W26GTDRB4C2D7H4NJBBGHFDAJPCTMYTN1H4E0HDDVMFAYHVATA",
        },
        function (msg) {
          MDS.log("MDS COMMAND TEST:" + JSON.stringify(msg))
        }
      )
    })
  }, [])
  return (
    <appContext.Provider value={{ loaded: loaded.current }}>
      {children}
    </appContext.Provider>
  )
}

export default AppProvider
