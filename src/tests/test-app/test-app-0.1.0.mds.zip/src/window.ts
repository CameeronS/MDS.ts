import { MDSObj } from "../../../src/types"
declare global {
  interface Window {
    MDS: MDSObj
  }
}
